library(testthat)
library(jqr)

test_check("jqr")
